package ejercicio04;
import utilidades.Leer;
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double radio;
		double altura;
		Cilindro cil;
		double total;
		Cilindro cil2;
		
		System.out.println("Di un radio");
		
		radio=Leer.datoDouble();
		
		System.out.println("Di una altura");
		
		altura=Leer.datoDouble();
		
		 cil=new Cilindro(radio, altura);
		 
		total=cil.calcularVolumen();
		 
		 cil.imprimirDatos(total);
		 
			System.out.println("\n\nDi segundo radio");
			
			radio=Leer.datoDouble();
			
			System.out.println("Di segunda altura");
			
			altura=Leer.datoDouble();
			
			 cil2=new Cilindro(radio, altura);
			 
			total=cil2.calcularVolumen();
			 
			 cil2.imprimirDatos(total);
		
	}

}
