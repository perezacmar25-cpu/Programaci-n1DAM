package ejercicio09;
import utilidades.Leer;
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int desde=1,hasta=99999, numPapeletas , num;
		Sorteo sor;
		double pagar;
		
		sor=new Sorteo(desde, hasta);
		
		System.out.println("¿Cuántos papeletas desea comprar?");
		numPapeletas=Leer.datoInt();
		System.out.println("¿Qué número quiere?");
		num=Leer.datoInt();
		System.out.println("¿Con cuánto va a pagar?");
		pagar=Leer.datoDouble();
		sor.comprarDecimo(numPapeletas);
		sor.devolucion(numPapeletas, pagar);
	}

}
