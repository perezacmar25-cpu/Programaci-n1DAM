package ejercicio01;

public class Cabecera {
	

		
		public void nombreAsignatura(String cabecera1, String cabecera2, String cabecera3) {
			
			
			System.out.printf("%s:_______________\t%s:__________________\t\t%s:____________________",cabecera1,cabecera2,cabecera3);
			
		}
		
		//getters and setters

		

}

		