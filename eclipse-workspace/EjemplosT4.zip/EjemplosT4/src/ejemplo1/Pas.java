package ejemplo1;

public class Pas extends Persona{
	
	private double sueldo;
	private double pagaHora;
	public Pas(String nombre, String apellidos, String dni, int id, int edad, double sueldo, double pagaHora) {
		super(nombre, apellidos, dni, id, edad);
		this.sueldo = sueldo;
		this.pagaHora = pagaHora;
	}
	
	
	
	
	
	
	
	
	

}
