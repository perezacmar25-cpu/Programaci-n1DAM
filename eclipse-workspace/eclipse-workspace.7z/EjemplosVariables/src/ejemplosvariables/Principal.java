package ejemplosvariables;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=40;
		int num2=7;
		int resultado;
		double precio=2.60;
		char letra='L';
		System.out.println("Hola, este programa suma dos números");
		System.out.println("El primero es: "+num1);
		System.out.println("El segundo es: "+num2);
		resultado=num1+num2;
		System.out.println("El resultado es: "+resultado);
		System.out.println("\nEl precio es: "+precio+" €");
		System.out.println("La letra es: "+letra);
		
		
		
	}	
	
	/*Declarar 3 variables de tipo entero(int) con valores 3,5,9. Sumarlas guardando el resultado en una nueva variable. Restar 1 a dicha variable
	 * 
	 */
}
