package Ejercicio01;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=3;
		int num2=5;
		int num3=9;
		int resultado=num1+num2+num3;
		int unidad=1;
		int resta=resultado-unidad;
		
		System.out.println("Bienvenidos a este programa. Este se dedica a sumar y restar números.");
		System.out.println("El resultado de la suma es: "+resultado);
		System.out.println("Si al resultado le restamos la unidad, nos queda:"+resta);
		
				
	}

}
