package ejercicio05;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double valor1=50;
		double valor2=1;
		double cambio=0.87;
		double resultado=valor1*cambio;
	
		 
		
		System.out.println("Bienvenido a este programa. Este programa realiza cambios de libras a euros y viceversa");
		System.out.println("Valor1= 50 euros");	
		System.out.println("Valor2= 1 libra");
		System.out.println("50 euros son: "+resultado);
		
	}

}
